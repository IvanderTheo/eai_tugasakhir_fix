package com.example.GrowBussiness;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrowBussinessApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrowBussinessApplication.class, args);
	}

}
