package com.example.GrowBussiness;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrowBussinessApplicationTests {

	@Test
	void contextLoads() {
	}

}
